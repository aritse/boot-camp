import React from "react";
import CardTitle from "../CardTitle";
import "./style.css";

function CardHeading() {
  return ( 
    <div>
      <CardTitle />
    </div> 
  );
}

export default CardHeading;
